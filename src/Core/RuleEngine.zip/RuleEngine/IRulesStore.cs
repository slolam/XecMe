﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.Activities.Rules;
using System.IO;
using System.Workflow.ComponentModel.Serialization;
using System.Xml;

namespace AmericanExpress.Cuso.Framework.RuleEngine
{
    public interface IRulesStore
    {
        RuleSet GetRuleSet(RuleName ruleName);
    }

    public class RuleName
    {
        public string Name
        { get; set; }
        public short Version
        { get; set; }
        public override string ToString()
        {
            return string.Format("{0},{1}", Name, Version);
        }
    }

    public static class RuleUtil
    {
        public static void Serialize(RuleSet ruleset, Stream stream)
        {
            using (XmlWriter rulesWriter = XmlWriter.Create(stream))
            {
                WorkflowMarkupSerializer serializer = new WorkflowMarkupSerializer();
                serializer.Serialize(rulesWriter, ruleset);
            }
        }
        public static void Serialize(RuleSet ruleset, StringBuilder sb)
        {
            using (XmlWriter rulesWriter = XmlWriter.Create(sb))
            {
                WorkflowMarkupSerializer serializer = new WorkflowMarkupSerializer();
                serializer.Serialize(rulesWriter, ruleset);
            }
        }
        public static RuleSet Deserialize(Stream stream)
        {
            using (XmlReader rulesReader = XmlReader.Create(stream))
            {
                WorkflowMarkupSerializer serializer = new WorkflowMarkupSerializer();
                return  (RuleSet)serializer.Deserialize(rulesReader);
            }
        }

        public static RuleSet Deserialize(string xml)
        {
            using (XmlReader rulesReader = XmlReader.Create(new StringReader(xml)))
            {
                WorkflowMarkupSerializer serializer = new WorkflowMarkupSerializer();
                return (RuleSet)serializer.Deserialize(rulesReader);
            }
        }
    }
}
