﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.Activities.Rules;

namespace AmericanExpress.Cuso.Framework.RuleEngine
{
    public class RuleEngine
    {
        private IRulesStore ruleStore;

        public void Execute<T>(RuleName ruleName, PolicyExecutionContext<T> context)
        {
            
        }

        public void Execute<T>(RuleSet ruleSet, PolicyExecutionContext<T> context)
        {
            RuleValidation validation = new RuleValidation(context.GetType(),null);
            RuleExecution execution = new RuleExecution(validation, context);
            ruleSet.Execute(execution);
        }
    }
}
